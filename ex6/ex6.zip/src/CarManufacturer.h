

#ifndef TASK2BFS_CARMANUFACTURER_H
#define TASK2BFS_CARMANUFACTURER_H

// Enum class - has kinds of car manufacturer.
enum class CarManufacturer {
    // Types of car.
            HONDA = 'H',
    SUBARO = 'S',
    TESLA = 'T',
    FIAT = 'F'
};


#endif //TASK2BFS_CARMANUFACTURER_H
