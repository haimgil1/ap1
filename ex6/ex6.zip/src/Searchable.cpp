
#include "Searchable.h"

Searchable::~Searchable() {

}

