//
// Created by chen on 30/11/16.
//

#ifndef TASK2BFS_ENUMSTATUS_H
#define TASK2BFS_ENUMSTATUS_H

// Enum class - has kind of marital status.
enum class MaritalStatus {
    // Marital types.
            SINGLE = 'S',
    MARRIED = 'M',
    DIVORCED = 'D',
    WIDOWED = 'W'
};
#endif //TASK2BFS_ENUMSTATUS_H
